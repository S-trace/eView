#!/bin/sh 
rm -rf .eView/